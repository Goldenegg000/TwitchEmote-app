# docs
## what this does:
it makes costume emotes for twitch<br>
thats it *bruh*