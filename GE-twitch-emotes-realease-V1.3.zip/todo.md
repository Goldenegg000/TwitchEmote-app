# TODO:

## finished:

&#9745; make info button and make it show infos<br>
&#9745; show infos of creators under emotes<br>
&#9745; make emotes be displayed on obs and other?<br>
&#9745; make a website?<br>

## will be added maby:

&#9744; channel only emotes? `[? - not for now unless the majority of people want that]`<br>
&#9744; SPOOPY EMOTES/GIFS `[? - maby next time]`<br>
&#9744; limit emote/gif file size `[? - only untill i hit the maximum copacity]`<br>
&#9744; publish it as a oficial extension `[? - i can only do that when im 18 so not for now]`<br>

## canceled:

&#9744; make da popup page updateble `[X - not going to do that becouse its too complex]`<br>

<br>

# other stuff

stream title stuff:
developing GET-Emotes, a web extension for costume emotes and gifs on twitch! | web development

Software and Game Development
