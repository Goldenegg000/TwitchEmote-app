// document.getElementById("clear-chat").addEventListener("click", () => {
//     document.getElementsByClassName("Layout-sc-nxg1ff-0 lgtHpz chat-scrollable-area__message-container")[0].innerHTML = "";
// });