# docs
## what this does:
it makes costume emotes<br>
thats it